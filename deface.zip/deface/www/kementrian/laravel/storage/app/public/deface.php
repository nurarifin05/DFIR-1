<?php
// index.php - Simulasi Edukasi Website Terkena Defacement Judi Online
// Dipakai khusus untuk keperluan materi presentasi / edukasi keamanan siber.

// Mengatur header agar browser mengenali ini sebagai dokumen HTML
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[HACKED BY SIMULATION] - DEFACEMENT SLOT</title>
    
    <!-- CSS DISATUKAN DALAM SATU FILE INDEX.PHP -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #0b0b0b;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Banner Edukasi di Paling Atas */
        .edu-warning-banner {
            width: 100%;
            background-color: #d9534f;
            color: #ffffff;
            text-align: center;
            padding: 10px 15px;
            font-weight: bold;
            font-size: 0.95rem;
            border-bottom: 2px solid #b52b27;
            box-shadow: 0 2px 10px rgba(0,0,0,0.5);
            z-index: 9999;
        }

        .main-container {
            width: 100%;
            max-width: 800px;
            padding: 20px;
            text-align: center;
        }

        /* Style khas Defacement / Hacktivism */
        .hacker-header {
            margin-top: 20px;
            margin-bottom: 15px;
        }

        .hacker-header h1 {
            color: #ff0055;
            font-size: 2.2rem;
            text-transform: uppercase;
            text-shadow: 0 0 10px #ff0055, 0 0 20px #ff0055;
            margin-bottom: 5px;
        }

        .hacker-header p {
            color: #00ffcc;
            font-size: 1.1rem;
            letter-spacing: 1px;
        }

        /* Running Text (Marquee) */
        .marquee-box {
            background-color: #1a1a1a;
            border: 1px solid #ffcc00;
            color: #ffcc00;
            padding: 8px;
            margin: 20px 0;
            font-weight: bold;
            border-radius: 4px;
        }

        /* Area Promosi Deface Judi Online */
        .deface-card {
            background: linear-gradient(145deg, #181818, #222222);
            border: 2px solid #ffd700;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 0 25px rgba(255, 215, 0, 0.2);
            margin-bottom: 25px;
        }

        .deface-card h2 {
            color: #ffd700;
            font-size: 1.8rem;
            margin-bottom: 10px;
            text-shadow: 0 0 8px rgba(255, 215, 0, 0.6);
        }

        .deface-card .promo-tag {
            background-color: #ff0000;
            color: #fff;
            display: inline-block;
            padding: 5px 15px;
            font-weight: bold;
            border-radius: 20px;
            margin-bottom: 15px;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .deface-card ul {
            list-style: none;
            margin: 15px 0;
            text-align: left;
            display: inline-block;
        }

        .deface-card ul li {
            margin: 8px 0;
            font-size: 1.05rem;
            color: #ddd;
        }

        .deface-card ul li::before {
            content: "✔ ";
            color: #00ff00;
            font-weight: bold;
        }

        /* Tombol Akses */
        .btn-group {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            font-size: 1.1rem;
            font-weight: bold;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-login {
            background: linear-gradient(180deg, #ffd700, #ff8c00);
            color: #000;
            border: none;
            box-shadow: 0 4px 15px rgba(255, 215, 0, 0.4);
        }

        .btn-register {
            background: linear-gradient(180deg, #00ffcc, #008b8b);
            color: #000;
            border: none;
            box-shadow: 0 4px 15px rgba(0, 255, 204, 0.4);
        }

        .btn:hover {
            transform: translateY(-3px);
            filter: brightness(1.2);
        }

        /* Footer Informasi */
        .footer-info {
            margin-top: 30px;
            font-size: 0.85rem;
            color: #666;
            border-top: 1px solid #333;
            padding-top: 15px;
            width: 100%;
        }
    </style>
</head>
<body>

    <!-- Banner Penjelas Simulasi -->
    <div class="edu-warning-banner">
        ⚠️ PERINGATAN: Ini adalah contoh SIMULASI EDUKASI tampilan website yang terkena serangan Web Defacement (Judi Online).
    </div>

    <div class="main-container">
        <!-- Header Defacer -->
        <div class="hacker-header">
            <h1>HACKED BY SIMULATION_TEAM</h1>
            <p>SECURITY IS JUST AN ILLUSION</p>
        </div>

        <!-- Teks Berjalan -->
        <div class="marquee-box">
            <marquee behavior="scroll" direction="left">
                SITUS INI TELAH DI-DIREK KE HALAMAN RESMI GACOR 2026 - DEPOSIT PULSA TANPA POTONGAN - BONUS NEW MEMBER 100%
            </marquee>
        </div>

        <!-- Kartu Promosi Defacement -->
        <div class="deface-card">
            <div class="promo-tag">SITUS GACOR TERPERCAYA</div>
            <h2>SLOT88 & PRAGMATIC PLAY</h2>
            <p>Selamat datang di portal resmi dengan RTP Tertinggi Hari Ini!</p>
            
            <ul>
                <li>Minimal Deposit: Rp 10.000</li>
                <li>Proses Transaksi Cepat & Aman</li>
                <li>RTP Live Update Setiap Jam</li>
                <li>Support Bank Local, E-Wallet & Pulsa</li>
            </ul>

            <div class="btn-group">
                <a href="#" class="btn btn-login" onclick="alert('Ini hanya simulasi tampilan defacement.')">LOGIN SEKARANG</a>
                <a href="#" class="btn btn-register" onclick="alert('Ini hanya simulasi tampilan defacement.')">DAFTAR AKUN</a>
            </div>
        </div>

        <!-- Footer / Greets -->
        <div class="footer-info">
            <p>Greets: Admin_Test | Security_Edu | Cyber_Lab</p>
            <p style="margin-top: 5px; color: #444;">[Hanya untuk keperluan pengujian & edukasi keamanan siber]</p>
        </div>
    </div>

</body>
</html>